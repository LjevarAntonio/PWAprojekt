<!DOCTYPE html>
<html>
<head>
    <meta name="autor" content="Antonio Ljevar">
    <meta charset="utf-8">
    <title>Administracija</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>


<body>
    <?php
        session_start();
        $dbc = mysqli_connect('localhost', 'root','', 'bazaprojekt') or
        die('Error connecting to MySQL server.'. mysqli_connect_error());
        

    ?>

    <header>
        <img id="logo" src="imgs/Logo.png" alt="">
        <div id="navigacija">
            <div class="centriranje">
                <nav>
                <a class="linkNav" href="index.php">HOME</a>
                    <a class="linkNav" href="unos.html">UNOS</a>
                    <a class="linkNav" href="administracija.php">ADMINISTRACIJA</a>
                    <a class="linkNav" href="kategorijaSport.php">SPORT</a>
                    <a class="linkNav" href="kategorijaZabava.php">ZABAVA</a>
                    <a class="linkNav" href="kategorijaPolitika.php">POLITIKA</a>
                    <a class="linkNav" href="kategorijaEkonomija.php">EKONOMIJA</a>
                    <a class="linkNav" href="registracija.php">REGISTACIJA</a>


                </nav>
            </div>
        </div>
    </header>

    <main>
        <section>
        
        <form action="" method="post">
        <p>Unesi svoj username:</p>
            <br>
            <input type="text" id="user" name="user">
            <br>
            <span id="pUse" ></span>
            <br>
            <p>Unesi svoj password:</p>
            <br>
            <input type="password" id="pass" name="pass">
            <br>
            <span id="pLoz" ></span>
            <br>
            <button type="submit" id="prijava" name="prijava">Prijavi me</button>


        </form>

        <script type="text/javascript">
                document.getElementById("prijava").onclick = function(event) {
                    var dForma= true;

                    var eUse = document.getElementById("user");
                    var use = document.getElementById("user").value;
                    
                    if (use.length == 0) {
                        dForma = false;
                        eUse.style.border="2px solid red";
                        document.getElementById("pUse").innerHTML="<br>Username se mora unijeti!<br>";
                    }


                    var ePas = document.getElementById("pass");
                    var pas = document.getElementById("pass").value;
                    
                    if (pas.length == 0) {
                        dForma = false;
                        epas.style.border="2px solid red";
                        document.getElementById("pLoz").innerHTML="<br>Password se mora unijeti!<br>";

                    }

                    if (dForma != true) {
                        event.preventDefault();
                    }


                }

            </script>
        <?php 
            if (isset($_POST['prijava'])) {
                $prijavaIme= $_POST['user'];
                $prijavaLozinka = $_POST['pass'];


                $sql = "SELECT korisnicko_ime, lozinka, razina FROM korisnik WHERE korisnicko_ime = ?";
                $stmt = mysqli_stmt_init($dbc);
                if (mysqli_stmt_prepare($stmt, $sql)) {
                    mysqli_stmt_bind_param($stmt, 's', $prijavaIme);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_store_result($stmt);
                }

                mysqli_stmt_bind_result($stmt, $imeK, $lozinkaK, $levelK);
                mysqli_stmt_fetch($stmt);
                
                if (password_verify($_POST['pass'], $lozinkaK) && mysqli_stmt_num_rows($stmt) > 0) {
                    
                    $Prijava= true;

                    if($levelK == 1) {
                        $admin = true;
                    }
                    else{
                        $admin = false;
                    }

                    $_SESSION['$username'] = $imeK;
                    $_SESSION['$level'] = $levelK;
                }
                else{
                    $Prijava= false;
                }
            }
            
            
            ?>
            <?php   
            
            if(isset($Prijava)){
            if (($Prijava == true && $admin == true) || (isset($_SESSION['$username'])) && $_SESSION['$level'] == 1) {
                $query = "SELECT * FROM letakinfo";
                $result = mysqli_query($dbc, $query);
                while($row = mysqli_fetch_array($result)) {

                    echo '<form action="" method="post">
                    <p>Naslov vijesti:</p>
                    <input type="text" id="naslov"  name="naslovVijesti" value="'.$row['naslov'].'">
                    <br>
                    <br>

                    <p>Kratak sadržaj vijesti:</p>
                    <textarea name="kratakSadrzaj" class="textA" cols="132" rows="10">'.$row['sazetak'].'</textarea>
                    <br>
                    <br>


                    <p>Sadržaj vijesti:</p>
                    <textarea name="vijest" class="textA" cols="132" rows="10">'.$row['vijest'].'</textarea>
                    <br>
                    <br>


                    <div class="form-item">
                    <label for="pphoto">Slika:</label>
                    <div class="form-field">

                    <input type="file" name="inputFile" id="inputFile" accept="image/*" value="'.$row['slika'].'"/>
                    <label for="inputFile" id="inputFileLabel">Odaberi Sliku</label>
                    <br>
                    <br>


                    <p class="pored">Kategorija vijest:</p>
                    <select name="kategorijaVijesti" id="" value="'.$row['kategorija'].'">

                    <option value="'.$row['kategorija'].'"  selected hidden>Odaberi..</option>
                        <option value="EKONOMIJA">Ekonomija</option>
                        <option value="SPORT">Sport</option>
                        <option value="ZABAVA">Zabava</option>
                        <option value="POLITIKA">Politika</option>
                    </select>
                    <br>
                    <br>
                    <p class="pored">Označite ako želite arhivirati vijest: </p>
                    <input type="checkbox" value="1" name="oznaka">
                    <br>
                    <br>


                    <input type="hidden" name="id"  value="'.$row['id'].'">
                    <button type="reset" value="ponisti">Poništi</button>
                    <button type="submit" name="izmjeni" value="Izmjeni">Izmjeni</button>
                    <button type="submit" name="izbrisi" value="Izbriši">Izbriši</button>
                    </form>';
                }
            }   
        
            else if ($Prijava == true && $admin == false) {
                echo '<p>' . $imeK . ', uspješno ste prijavljeni, ali nemate administrativna prava.</p>';


            } 
            else if (isset($_SESSION['$username']) && $_SESSION['$level'] == 0) {

                echo '<p>' . $_SESSION['$username'] . ', uspješno ste prijavljeni, ali nemate administrativna prava.</p>';
            }}
    

            
        ?>
        

            
            

            
            

        </section>


    </main>

    
    <footer>
        <div class="centriranje">
            <p>Antonio Ljevar</p>
            <p>aljevar@tvz.hr</p>
            <p>2021/22</p>

        </div>


    </footer>


</body>
</html>

<?php

    if(isset($_POST['izbrisi']))
        {


            $id=$_POST['id'];
            $query2 = "DELETE FROM letakinfo WHERE id=$id ";
            $result = mysqli_query($dbc, $query2);  
        }

    if(isset($_POST['izmjeni'])){


        $slika = $_POST['inputFile'];
        $naslov=$_POST['naslovVijesti'];
        $kSadrzaj=$_POST['kratakSadrzaj'];
        $vijest=$_POST['vijest'];
        $kategorija=$_POST['kategorijaVijesti'];
        if (isset($_POST["oznaka"]))
        {
           $oznaka=$_POST["oznaka"];
        }
        else
        {
            $oznaka=0;
        }
        $id=$_POST['id'];
        $query3 = "UPDATE letakinfo SET naslov='$naslov', sazetak='$kSadrzaj', vijest='$vijest',
        slika='$slika', kategorija='$kategorija', oznaka='$oznaka' WHERE id=$id ";
        $result = mysqli_query($dbc, $query3);
    }
   
    mysqli_close($dbc);

?>
