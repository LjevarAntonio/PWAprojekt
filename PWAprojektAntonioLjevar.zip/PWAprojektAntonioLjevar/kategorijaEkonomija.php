<!DOCTYPE html>
<html>
<head>
    <meta name="autor" content="Antonio Ljevar">
    <meta charset="utf-8">
    <title>Sport</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>


<body>

    <header>
        <img id="logo" src="imgs/Logo.png" alt="">
        <div id="navigacija">
            <div class="centriranje">
                <nav>
                    <a class="linkNav" href="index.php">HOME</a>
                    <a class="linkNav" href="unos.html">UNOS</a>
                    <a class="linkNav" href="administracija.php">ADMINISTRACIJA</a>
                    <a class="linkNav" href="kategorijaSport.php">SPORT</a>
                    <a class="linkNav" href="kategorijaZabava.php">ZABAVA</a>
                    <a class="linkNav" href="kategorijaPolitika.php">POLITIKA</a>
                    <a class="linkNav" href="kategorijaEkonomija.php">EKONOMIJA</a>
                    <a class="linkNav" href="registracija.php">REGISTACIJA</a>


                </nav>
            </div>
        </div>
    </header>

    <main>
        
        <h1>Ekonomija</h1>

        <section>
            <?php 
                $dbc = mysqli_connect('localhost', 'root','', 'bazaprojekt') or
                die('Error connecting to MySQL server.'. mysqli_connect_error());

        

                $query = "SELECT * FROM letakinfo WHERE kategorija='EKONOMIJA'";
                $result = mysqli_query($dbc, $query);
                while($row = mysqli_fetch_array($result)) {
                    echo "<a href='clanak.php?id=".$row["id"]."'>";
                    echo "<article class='kategorijeNovostiArticle'>";
                    echo "<img class='articleSlika' src='";
                    echo $row['slika'];
                    echo "'>";
                    echo "<h3>";
                    echo $row['naslov'];
                    echo  "</h3>";
                    echo "<p class='opis'>";
                    echo $row['sazetak'];
                    echo "</p>";
                    echo"</article>";
                    echo "</a>";
                }
                    
                

            ?>
            <div class="clear"></div>


        </section>

    </main>

    <footer>
        <div class="centriranje">
            <p>Antonio Ljevar</p>
            <p>aljevar@tvz.hr</p>
            <p>2021/22</p>

        </div>


    </footer>

    
</body>