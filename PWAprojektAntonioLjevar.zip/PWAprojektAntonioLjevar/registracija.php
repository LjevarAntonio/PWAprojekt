<!DOCTYPE html>
<html>
<head>
    <meta name="autor" content="Antonio Ljevar">
    <meta charset="utf-8">
    <title>Registracija</title>
    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

    <header>
        <img id="logo" src="imgs/Logo.png" alt="">
        <div id="navigacija">
            <div class="centriranje">
                <nav>
                <a class="linkNav" href="index.php">HOME</a>
                    <a class="linkNav" href="unos.html">UNOS</a>
                    <a class="linkNav" href="administracija.php">ADMINISTRACIJA</a>
                    <a class="linkNav" href="kategorijaSport.php">SPORT</a>
                    <a class="linkNav" href="kategorijaZabava.php">ZABAVA</a>
                    <a class="linkNav" href="kategorijaPolitika.php">POLITIKA</a>
                    <a class="linkNav" href="kategorijaEkonomija.php">EKONOMIJA</a>
                    <a class="linkNav" href="registracija.php">REGISTACIJA</a>


                </nav>
            </div>
        </div>
    </header>


    <main>
        <h1>Registracija</h1>
        <section>
            
            <?php
                $regKorisnik = '';
                
            ?>
        
        

            <?php 
                if($regKorisnik == true) {
                    echo '<br><p>Korisnik je uspješno registriran!</p>';
                } 
                
                else {
            
            ?>
            
            <form  method="post" >
                <p>Unesi svoje ime:</p>
                <br>
                <input type="text" id="ime" name="ime">
                <br>
                <span id="pIme" ></span>
                <br>
                <p>Unesi svoje prezime:</p>
                <br>
                <input type="text" id="prezime" name="prezime">
                <br>
                <span id="pPrezime" ></span>
                <br>
                <p>Unesi korisnicko ime:</p>
                <br>
                <input type="text" id="username" name="korisnickoIme">
                <br>
                <span id="pUsername" ></span>
                <br>
                <p>Unesi lozinku:</p>
                <br>
                <input type="password" id="lozinka" name="lozinka">
                <br>
                <span id="pLozinka" ></span>
                <br>
                <p>Ponovi lozinu:</p>
                <br>
                <input type="password" id="lozinka2" name="lozinka2">
                <br>
                <span id="pLozinka2" ></span>
                <br>
                <button type="submit" id="registracija" name="registracija">Registriraj me</button>


            </form>
        </section>
        <?php } ?>

        <script type="text/javascript">
        document.getElementById("registracija").onclick = function(event) {
            var daljeForma= true;

            var eIme = document.getElementById("ime");
            var ime = document.getElementById("ime").value;
            
            if (ime.length == 0) {
                daljeForma = false;
                eIme.style.border="2px solid red";
                document.getElementById("pIme").innerHTML="<br>Ime se mora unijeti!<br>";
            }


            var ePrezime = document.getElementById("prezime");
            var prezime = document.getElementById("prezime").value;
            
            if (prezime.length == 0) {
                daljeForma = false;
                ePrezime.style.border="2px solid red";
                document.getElementById("pPrezime").innerHTML="<br>Prezime se mora unijeti!<br>";

            }

            var eUsername = document.getElementById("username");
            var username = document.getElementById("username").value;
            
            if (username.length == 0) {
                daljeForma = false;
                eUsername.style.border="2px solid red";
                document.getElementById("pUsername").innerHTML="<br>Korisničko ime se mora unijeti!<br>";

            }

            var eLozinka= document.getElementById("lozinka");
            var lozinka = document.getElementById("lozinka").value;
            var eLozinka2 = document.getElementById("lozinka2");
            var lozinka2 = document.getElementById("lozinka2").value;

            if (lozinka.length == 0 || lozinka2.length == 0 || lozinka != lozinka2) {
                daljeForma = false;
                eLozinka.style.border="2px solid red";
                eLozinka2.style.border="2px solid red";
                document.getElementById("pLozinka").innerHTML="<br>Lozinke nisu iste!<br>";
                document.getElementById("pLozinka2").innerHTML="<br>Lozinke nisu iste!<br>";
            }
            if (daljeForma != true) {
                event.preventDefault();
            }


        }

        </script>
        

        <?php
            if(isset($_POST['ime'], $_POST['prezime'], $_POST['korisnickoIme'], $_POST['lozinka'])){
                $ime = $_POST['ime'];
                $prezime = $_POST['prezime'];
                $korisnickoIme = $_POST['korisnickoIme'];
                $lozinka = $_POST['lozinka'];
                $hashed_password = password_hash($lozinka, CRYPT_BLOWFISH);
                $razina = 0;
               


                $dbc = mysqli_connect('localhost', 'root','', 'bazaprojekt') or
                die('Error connecting to MySQL server.'. mysqli_connect_error());


                $sql = "SELECT korisnicko_ime FROM korisnik WHERE korisnicko_ime = ?";
                $stmt = mysqli_stmt_init($dbc);

                if (mysqli_stmt_prepare($stmt, $sql)) {
                    mysqli_stmt_bind_param($stmt, 's', $korisnickoIme);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_store_result($stmt);
                }


                if(mysqli_stmt_num_rows($stmt) > 0){
                    $poruka='Korisničko ime već postoji!';
                }
                    else{

                        $sql = "INSERT INTO korisnik (ime, prezime,korisnicko_ime, lozinka,
                        razina)VALUES (?, ?, ?, ?, ?)";
                        $stmt = mysqli_stmt_init($dbc);


                        if (mysqli_stmt_prepare($stmt, $sql)) {
                            mysqli_stmt_bind_param($stmt, 'ssssd', $ime, $prezime, $korisnickoIme,
                            $hashed_password, $razina);
                            mysqli_stmt_execute($stmt);
                            $regKorisnik = true;
                        }


                }
                mysqli_close($dbc);
                }



        ?>


    </main>


    <footer>
        <div class="centriranje">
            <p>Antonio Ljevar</p>
            <p>aljevar@tvz.hr</p>
            <p>2021/22</p>

        </div>


    </footer>
    

</body>

</html>

