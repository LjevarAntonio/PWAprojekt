
















<!DOCTYPE html>
<html>
    <head>
        <meta name="autor" content="Antonio Ljevar">
        <meta charset="utf-8">
        <title>Article</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
<body>

    <header>
        <img id="logo" src="imgs/Logo.png" alt="">
        <div id="navigacija">
            <div class="centriranje">
                <nav>
                    <a class="linkNav" href="index.php">HOME</a>
                    <a class="linkNav" href="unos.html">UNOS</a>
                    <a class="linkNav" href="administracija.php">ADMINISTRACIJA</a>
                    <a class="linkNav" href="kategorijaSport.php">SPORT</a>
                    <a class="linkNav" href="kategorijaZabava.php">ZABAVA</a>
                    <a class="linkNav" href="kategorijaPolitika.php">POLITIKA</a>
                    <a class="linkNav" href="kategorijaEkonomija.php">EKONOMIJA</a>
                    <a class="linkNav" href="registracija.php">REGISTACIJA</a>
                </nav>
            </div>
        </div>
    </header>

    <main>
        <section>
        <?php
           
           if (isset($_POST["oznaka"]))
        {
           $oznaka=$_POST["oznaka"];
        }
        else{
            $oznaka=0;
        }
       ?>
            
            <h3>
                <?php 

                    if (isset($_POST['kategorijaVijesti']))
                    {
                        $kategorija=$_POST['kategorijaVijesti'];
                        echo $kategorija;
                    }
                
                
                
                ?>
            </h3>
            <h4>
                <?php

                    if (isset($_POST["naslovVijesti"]))
                    {
                        $naslov=$_POST["naslovVijesti"];
                        echo $naslov;
                    }
                
                


               
                ?>
            </h4>
            
            <h5>Published dd/mm/yy at hh:mm</h5>
            
            <?php

                    if (isset($_POST["inputFile"]))
                    {
                        $picture=$_POST["inputFile"];
                        echo"<img class='articleSlikaV' src='imgs/$picture' alt=''>";
                        
                         
                    }    
                
                

               
                ?>
            
        
        
            <p  id="shortP">
                <?php

                    if (isset($_POST["kratakSadrzaj"]))
                    {
                        $kSadrzaj=$_POST["kratakSadrzaj"];
                        echo $kSadrzaj;
                    }    
                
                

               
                ?>


            </p>

            <p  class="paragrafArticle">
                <?php 

                    if (isset($_POST["vijest"]))
                    {
                        $vijest=$_POST["vijest"];
                        echo $vijest;
                    }
                
                
               
                ?>
            </p>

            
            

        </section>

    </main>

    <footer>
        <div class="centriranje">
            <p>Antonio Ljevar</p>
            <p>aljevar@tvz.hr</p>
            <p>2021/22</p>

        </div>


    </footer>
</body>

<?php 

$dbc = mysqli_connect('localhost', 'root', '', 'bazaprojekt') or
die('Error connecting to MySQL server.'. mysqli_connect_error());


    $query = "INSERT INTO letakinfo (oznaka, kategorija, naslov, slika, sazetak, vijest) 
    VALUES ('$oznaka', '$kategorija', '$naslov','$picture', '$kSadrzaj', '$vijest' )";
    
    $result = mysqli_query($dbc, $query) or die('Error querying databese.');
    
    
    


mysqli_close($dbc);
?>
</html>



